# Realm Idle Save Downloader

An unofficial local tool for downloading your own Realm Idle cloud save. Internet access and the Google account you use in the game are required.

## Windows: Easiest Setup

1. Download the **Windows x64 portable ZIP** and choose **Extract All**. Do not run the launcher from inside the ZIP.
2. Open the extracted folder and double-click **Start Save Downloader.cmd**. No Node.js installation, terminal commands, or administrator access are needed.
3. Your normal browser opens. Click **Sign In with Google and Download Save**, then choose the Google account you use in the game.
4. Your browser downloads a timestamped JSON file, normally to Downloads. If needed, click **Download JSON Again** on the page.
5. Close the browser tab and launcher window when finished.

The portable edition includes the official Windows x64 Node.js runtime and its license. It targets Windows 10/11 on Intel/AMD x64. On other platforms, use the lightweight edition with your platform’s Node.js LTS installation.

## Lightweight Edition: Windows, macOS, and Linux

Install Node.js LTS (22 or newer) from [nodejs.org](https://nodejs.org/en/download/), then extract the lightweight ZIP.

On Windows, double-click **Start Save Downloader.cmd**. On macOS or Linux, open a terminal in the extracted folder and run:

```sh
node server.cjs
```

There is no npm install, account setup, API key entry, or configuration step. If the browser does not open automatically, copy the localhost address printed in the launcher window. To start without opening a browser, run `node server.cjs --no-open`.

## Which Save Is Downloaded?

The JSON is the game object from the signed-in account’s latest cloud snapshot, without changing or calculating its contents. It is not a fresh export of unsynced progress on your phone. For the latest progress, save to the cloud in the game first.

Each export has a new timestamped filename. It can be kept as a backup or imported into compatible Realm Idle tools. It is not a guarantee that every version of the game supports importing raw JSON.

## Privacy

- Google handles sign-in in its own window; this tool has no password field.
- The browser reads only `saves/<signed-in UID>` directly from the game’s Firebase service. The tool makes no writes to game data and does not run the game or process offline progress. Normal authentication may update sign-in metadata at Google/Firebase.
- Firebase authentication uses memory-only persistence. The tool disconnects the database and attempts sign-out after every attempt, including errors.
- No authentication tokens, credentials, or saves are sent to the local server. The server only serves a fixed list of page/SDK files and listens on this computer’s loopback interface.
- The downloaded save contains personal game data. Keep it private. The page keeps a download link in memory until you retry or close the tab.
- This package has no analytics, account-specific examples, or developer’s save files. It uses the game’s public Firebase client configuration and the Apache-licensed Firebase SDK.

## Troubleshooting

**Nothing opens:** keep the launcher window open and enter its printed `http://localhost:…/` address in a normal browser. Opening `index.html` directly will not work.

**Popup blocked or sign-in stuck:** allow popups for the local page, or try Firefox in a normal browser window. Do not use an embedded app browser. Do not turn off browser security globally.

**No cloud save:** select the same Google account used in the game and make a cloud save there first.

**Localhost is unauthorized:** the game’s Firebase project owner controls authorized sign-in domains. This package cannot change those settings. See [Firebase’s authentication troubleshooting](https://firebase.google.com/docs/auth/faq-and-troubleshooting).

**Access denied or unexpected format:** the service’s access rules or save format may have changed. No file is downloaded when ownership or structure validation fails.

**Windows warning:** the launcher is an unsigned local script. Review the files or ask the person who supplied the package if you do not trust its origin. The launcher does not request administrator access or change system settings.

## Licenses

The downloader code is provided under the MIT license in `LICENSE.txt`. Firebase SDK files retain their notices and are covered by `sdk/LICENSE.txt`. The Windows portable edition additionally includes Node.js license notices in `runtime/LICENSE.txt`.
