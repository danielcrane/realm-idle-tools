'use strict';
// Public Firebase client configuration, not credentials. No account IDs are embedded.
const firebaseConfig = {
  apiKey: 'AIzaSyCDx01s_hceIRxiqZ5szfxHICct80mFDxM',
  authDomain: 'realmidle-1648f.firebaseapp.com',
  databaseURL: 'https://realmidle-1648f-default-rtdb.firebaseio.com',
  projectId: 'realmidle-1648f',
  appId: '1:15457388392:web:32a68855e6d7ac2bcff8dd'
};

const button = document.getElementById('login');
const status = document.getElementById('status');
const download = document.getElementById('download');
const snapshotInfo = document.getElementById('snapshot');
let downloadUrl;

function clearDownload() {
  if (downloadUrl) URL.revokeObjectURL(downloadUrl);
  downloadUrl = undefined;
  download.hidden = true;
  download.removeAttribute('href');
  snapshotInfo.hidden = true;
  snapshotInfo.textContent = '';
}
window.addEventListener('pagehide', clearDownload);

function explain(error) {
  const messages = {
    'auth/popup-blocked': 'Your browser blocked the Google window. Allow popups for this local page and try again.',
    'auth/popup-closed-by-user': 'Sign-in was closed. You can try again whenever you are ready.',
    'auth/cancelled-popup-request': 'Sign-in was cancelled. Please try again.',
    'auth/unauthorized-domain': 'The game’s sign-in service is not allowing localhost. This needs a change by the game’s Firebase project owner; choosing another port will not fix it.',
    'auth/network-request-failed': 'Could not reach Google. Check your internet connection and try again.',
    'PERMISSION_DENIED': 'The game’s service denied access to this account’s save. Check that you selected the Google account used in the game.',
    'permission_denied': 'The game’s service denied access to this account’s save. Check that you selected the Google account used in the game.',
    'no-save': 'No cloud save was found for this Google account. Save to the cloud in Realm Idle, then try again with the same account.',
    'invalid-save': 'The cloud save has an unexpected format. No file was downloaded.',
    'wrong-owner': 'The save’s account ID does not match your sign-in. No file was downloaded.',
    'read-timeout': 'Reading the cloud save timed out. Check your connection and try again.'
  };
  return messages[error.code] || 'Could not retrieve the save. Try again in a normal Firefox window. The game’s service may also be temporarily unavailable.';
}
function failure(code) { return Object.assign(new Error(code), {code}); }

try {
  firebase.initializeApp(firebaseConfig);
  const auth = firebase.auth();
  const database = firebase.database();
  database.goOffline();

  button.onclick = async () => {
    button.disabled = true;
    clearDownload();
    let timer;
    let game;
    let cloudTimestamp;
    let problem;
    let signOutFailed = false;
    try {
      status.textContent = 'Opening Google sign-in…';
      const provider = new firebase.auth.GoogleAuthProvider();
      provider.setCustomParameters({prompt: 'select_account'});
      // Invoke the popup directly from the click to retain the browser’s user gesture.
      const result = await auth.signInWithPopup(provider);
      status.textContent = 'Signed in. Reading your cloud save…';
      database.goOnline();
      const snapshot = await Promise.race([
        database.ref('saves/' + result.user.uid).once('value'),
        new Promise((_, reject) => { timer = setTimeout(() => reject(failure('read-timeout')), 25000); })
      ]);
      if (!snapshot.exists()) throw failure('no-save');
      const cloud = snapshot.val();
      game = cloud && cloud.game;
      if (!game || typeof game !== 'object' || !game.skills || !game.inv) throw failure('invalid-save');
      if (game.ownerUid !== result.user.uid) throw failure('wrong-owner');
      cloudTimestamp = cloud.timestamp;
    } catch (error) {
      problem = explain(error);
      game = undefined;
    } finally {
      clearTimeout(timer);
      database.goOffline();
      status.textContent = 'Signing out…';
      try { await auth.signOut(); } catch { signOutFailed = true; }
    }
    if (game) {
      try {
        const stamp = new Date().toISOString().replace(/[:.]/g, '-');
        downloadUrl = URL.createObjectURL(new Blob([JSON.stringify(game)], {type: 'application/json'}));
        download.href = downloadUrl;
        download.download = 'realm-idle-save-' + stamp + '.json';
        download.hidden = false;
        const date = typeof cloudTimestamp === 'number' && Number.isFinite(cloudTimestamp) ? new Date(cloudTimestamp) : null;
        snapshotInfo.textContent = date && !Number.isNaN(date.valueOf()) ? 'Cloud snapshot: ' + date.toLocaleString() + '. This is the last cloud save, before any new offline progress.' : 'This is your latest stored cloud snapshot, before any new offline progress.';
        snapshotInfo.hidden = false;
        status.textContent = 'Your save is ready. If the download does not start, use Download JSON Again below.';
        download.click();
      } catch { problem = 'The browser could not create the download. Try again in Firefox.'; clearDownload(); }
    }
    if (problem) status.textContent = problem;
    if (signOutFailed) status.textContent += '\nSign-out could not be confirmed. Close this tab to clear the in-memory session.';
    button.textContent = 'Sign In and Download Again';
    button.disabled = false;
  };
  auth.setPersistence(firebase.auth.Auth.Persistence.NONE).then(() => {
    status.textContent = 'Ready. Google will open its own sign-in window.';
    button.textContent = 'Sign In with Google and Download Save';
    button.disabled = false;
  }).catch(() => { status.textContent = 'Could not prepare a private sign-in session. Reload this page or try Firefox.'; });
} catch {
  status.textContent = 'The downloader could not start. Extract the complete ZIP, run the launcher, and open its localhost address.';
}
