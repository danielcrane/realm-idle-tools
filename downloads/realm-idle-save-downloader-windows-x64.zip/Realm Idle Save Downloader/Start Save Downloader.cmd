@echo off
setlocal
title Realm Idle Save Downloader
cd /d "%~dp0"
if exist "%~dp0runtime\node.exe" (
  "%~dp0runtime\node.exe" "%~dp0server.cjs"
  goto finished
)
where node >nul 2>nul
if errorlevel 1 (
  echo This is the lightweight edition. It needs Node.js 22 or newer.
  echo Install the LTS version from https://nodejs.org/en/download/
  echo Then close this window and double-click this launcher again.
  echo Or use the Windows portable ZIP, which includes Node.js.
  pause
  exit /b 1
)
node "%~dp0server.cjs"
:finished
if errorlevel 1 (
  echo.
  echo The downloader could not start. Keep all extracted files together.
  pause
)
