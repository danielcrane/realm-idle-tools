'use strict';
// Static loopback server only: credentials and save data never reach this process.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const {spawn} = require('node:child_process');

const routes = new Map([
  ['/', ['index.html', 'text/html; charset=utf-8']],
  ['/app.js', ['app.js', 'text/javascript; charset=utf-8']],
  ['/style.css', ['style.css', 'text/css; charset=utf-8']],
  ...['app', 'auth', 'database'].map(name => [`/sdk/firebase-${name}-compat.js`, [`sdk/firebase-${name}-compat.js`, 'text/javascript; charset=utf-8']])
]);

function createServer() {
  const server = http.createServer((req, res) => {
    const port = server.address().port;
    const headers = {
      'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff',
      'X-Frame-Options': 'DENY', 'Referrer-Policy': 'no-referrer',
      'Cross-Origin-Resource-Policy': 'same-origin',
      'Content-Security-Policy': "default-src 'none'; script-src 'self' https://apis.google.com; style-src 'self'; connect-src https://apis.google.com https://*.googleapis.com https://*.firebaseio.com wss://*.firebaseio.com https://realmidle-1648f.firebaseapp.com; frame-src https://realmidle-1648f.firebaseapp.com https://apis.google.com; img-src 'self' data: https://*.googleusercontent.com; base-uri 'none'; form-action 'none'; frame-ancestors 'none'; object-src 'none'"
    };
    function reply(code, body, type = 'text/plain; charset=utf-8') {
      res.writeHead(code, {...headers, 'Content-Type': type}); res.end(body);
    }
    if (![`localhost:${port}`, `127.0.0.1:${port}`].includes(req.headers.host)) return reply(403, 'Invalid host.');
    if (req.headers['sec-fetch-site'] === 'cross-site' && req.headers['sec-fetch-mode'] !== 'navigate') return reply(403, 'Cross-site request blocked.');
    if (req.method !== 'GET') return reply(405, 'This server only serves the downloader page.');
    // Match raw paths: no filesystem paths or directory browsing are accepted.
    const route = routes.get(req.url);
    if (!route) return reply(404, 'Not found.');
    fs.readFile(path.join(__dirname, route[0]), (error, data) => {
      if (error) return reply(500, 'A downloader file is missing. Extract the complete ZIP and try again.');
      reply(200, data, route[1]);
    });
  });
  server.requestTimeout = 15000;
  server.headersTimeout = 10000;
  return server;
}

function openBrowser(url) {
  const [command, args] = process.platform === 'win32'
    ? ['cmd.exe', ['/d', '/s', '/c', `start "" "${url}"`]]
    : process.platform === 'darwin' ? ['open', [url]] : ['xdg-open', [url]];
  const child = spawn(command, args, {stdio: 'ignore', windowsHide: true});
  child.on('error', () => console.log('Open the address above in your browser.'));
  child.unref();
}

if (require.main === module) {
  const server = createServer();
  server.on('error', error => { console.error('Could not start the local downloader:', error.code); process.exitCode = 1; });
  server.listen(0, '127.0.0.1', () => {
    const url = `http://localhost:${server.address().port}/`;
    console.log(`\nRealm Idle Save Downloader\n\n${url}\n\nKeep this window open while downloading. Close it or press Ctrl+C when finished.\n`);
    if (!process.argv.includes('--no-open')) openBrowser(url);
  });
  process.on('SIGINT', () => { server.close(); server.closeAllConnections(); });
}
module.exports = {createServer};
